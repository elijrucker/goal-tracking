# Backlog

A holding area for potential future cards, ideas, and goals that haven't been assigned to the deck yet. Review periodically to determine if any backlog items should replace or supplement existing cards.

---

## Potential Diamonds Cards (Tools & Platforms)

- [ ] Linux/Bash scripting (deeper terminal proficiency)
- [ ] PostgreSQL / database tooling
- [ ] GraphQL
- [ ] TypeScript
- [ ] React (deep dive)
- [ ] Django framework
- [ ] Terraform / Infrastructure as Code
- [ ] Vim / Neovim proficiency
- [ ] Git advanced usage (rebasing, workflows, etc.)

---

## Potential Clubs Cards (Applied Practice)

- [ ] Contribute tests to an open source project
- [ ] Build a CLI tool
- [ ] Build a Chrome extension
- [ ] Build a mobile app (React Native)
- [ ] Refactor an existing project using TDD
- [ ] Complete Advent of Code (any year)
- [ ] Build a personal portfolio website

---

## Potential Spades Cards (Theory & Math)

- [ ] Linear Algebra (e.g., MIT OpenCourseWare)
- [ ] Probability & Statistics
- [ ] Computational Complexity Theory
- [ ] Introduction to the Theory of Computation
- [ ] Compilers course
- [ ] Computer Networks course
- [ ] Multivariable Calculus

---

## Potential Hearts Cards (Personal Development)

- [ ] EU relocation logistics (visa, housing, banking)
- [ ] Polish B1 Certification (intermediate milestone before C1)
- [ ] Read non-technical books (TBD)
- [ ] Meditation / mindfulness practice
- [ ] Additional language (German - useful for Berlin)
- [ ] Contribute to Polish-speaking developer community

---

## Wildcard / Joker Ideas

- [ ] Joker 2: TBD - reserved for unexpected high-value opportunity

---

## Review Log

| Date | Items Reviewed | Added to Deck | Dropped |
|------|---------------|---------------|---------|
| 2026-02-13 | Initial backlog created | 0 | 0 |

---

## Notes

- Review backlog quarterly or after completing a card
- Consider whether backlog items have become more or less relevant
- Open slots in Diamonds (2 remaining) and any suit with future vacancies are candidates for backlog promotion
